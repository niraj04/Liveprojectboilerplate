# Frontend Base

## Install Packages

Install Node dependencies.

    npm install --legacy-peer-deps

---

## Compile Assets

Run app in development mode.

    npm start

Build app in development mode for building the static assets. (without CDN)

    npm run build-dev

Build app in production mode for building the static assets. (with CDN)

    npm run build