import $ from 'jquery'
import "slick-carousel"

